package com.example.maks.filesstatisticapp;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by maks on 27.03.2015.
 */
public class DataPacking implements Parcelable{
    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {

    }
}
